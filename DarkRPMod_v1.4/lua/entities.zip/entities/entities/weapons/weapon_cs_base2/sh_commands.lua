AddCSLuaFile()

DarkRP.declareChatCommand{
    command = "drop",
    description = "Drop the weapon you're holding.",
    delay = 1.5
}

DarkRP.declareChatCommand{
    command = "dropweapon",
    description = "Drop the weapon you're holding.",
    delay = 1.5
}

DarkRP.declareChatCommand{
    command = "weapondrop",
    description = "Drop the weapon you're holding.",
    delay = 1.5
}
