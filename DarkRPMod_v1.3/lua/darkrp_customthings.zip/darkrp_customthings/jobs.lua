DarkRP.createCategory{
    name = "Evocity Citizens",
    categorises = "jobs",
    startExpanded = true,
    color = Color(0, 107, 0, 255),
    canSee = fp{fn.Id, true},
    sortOrder = 100,
}

DarkRP.createCategory{
	name = "Evocity Police",
	categorises = "jobs",
	startExpanded = true,
	color = Color(25, 25, 170, 255),
	canSee = fp{fn.Id, true},
	setOrder = 101,
}

DarkRP.createCategory{
    name = "Evocity Criminals",
    categorises = "jobs",
    startExpanded = true,
    color = Color(75, 75, 75, 255),
    canSee = fp{fn.Id, true},
    sortOrder = 105,
}

DarkRP.createCategory{
    name = "Other",
    categorises = "jobs",
    startExpanded = true,
    color = Color(0, 107, 0, 255),
    canSee = fp{fn.Id, true},
    sortOrder = 255,
}
TEAM_CITIZEN = DarkRP.createJob("Citizen", {
    color = Color(20, 150, 20, 255),
    model = {
        "models/player/Group01/Female_01.mdl",
        "models/player/Group01/Female_02.mdl",
        "models/player/Group01/Female_03.mdl",
        "models/player/Group01/Female_04.mdl",
        "models/player/Group01/Female_06.mdl",
        "models/player/group01/male_01.mdl",
        "models/player/Group01/Male_02.mdl",
        "models/player/Group01/male_03.mdl",
        "models/player/Group01/Male_04.mdl",
        "models/player/Group01/Male_05.mdl",
        "models/player/Group01/Male_06.mdl",
        "models/player/Group01/Male_07.mdl",
        "models/player/Group01/Male_08.mdl",
        "models/player/Group01/Male_09.mdl"
    },
    description = [[The Citizen is the most basic level of society you can hold besides being a hobo. You have no specific role in city life.]],
    weapons = {},
    command = "citizen",
    max = 0,
    salary = 50,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Evocity Citizens"
})
TEAM_GANG = DarkRP.createJob("Gangster", {
    color = Color(255, 0, 0, 255),
    model = {
        "models/player/Group03/Female_01.mdl",
        "models/player/Group03/Female_02.mdl",
        "models/player/Group03/Female_03.mdl",
        "models/player/Group03/Female_04.mdl",
        "models/player/Group03/Female_06.mdl",
        "models/player/group03/male_01.mdl",
        "models/player/Group03/Male_02.mdl",
        "models/player/Group03/male_03.mdl",
        "models/player/Group03/Male_04.mdl",
        "models/player/Group03/Male_05.mdl",
        "models/player/Group03/Male_06.mdl",
        "models/player/Group03/Male_07.mdl",
        "models/player/Group03/Male_08.mdl",
        "models/player/Group03/Male_09.mdl"
    },
    description = [[The lowest person of crime.
        A gangster generally works for the Mobboss who runs the crime family.
        The Mob boss sets your agenda and you follow it or you might be punished.]],
    weapons = {},
    command = "gangster",
    max = 3,
    salary = 50,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Evocity Criminals",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(-1)
        ply:SetHealth(-1)
    end
})
TEAM_MOB = DarkRP.createJob("Mob Boss", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gman_high.mdl"},
    description = [[The Mob boss is the boss of the criminals in the city.
        With his power he coordinates the gangsters and forms an efficient crime organization.
        He has the ability to break into houses by using a lockpick.
        The Mob boss posesses the ability to unarrest you.]],
    weapons = {"lockpick", "unarrest_stick"},
    command = "mobboss",
    max = 1,
    salary = 75,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = true,
    category = "Evocity Criminals"
})
TEAM_HITMAN = DarkRP.createJob("Hitman", {
    color = Color(0, 0, 0, 255),
    model = {"models/player/leet.mdl"},
    description = [[You kill people, it's pretty simple.
	Someone tells you to kill someone and the rest is left up to your imagination.]],
    weapons = {"m9k_winchester73"},
    command = "bountyhunter",
    max = 1,
    salary = 65,
    admin = 0,
    vote = false,
    hasLicense = true,
    candemote = true,
    category = "Evocity Criminals",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "The Hitman was killed")
    end
})
TEAM_GUN = DarkRP.createJob("Gun Dealer", {
    color = Color(21, 217, 99, 255),
    model = {"models/player/eli.mdl"},
    description = [[A Gun Dealer is the only person who can sell guns to other people.
        Make sure you aren't caught selling illegal firearms to the public! You might get arrested!]],
    weapons = {},
    command = "gundealer",
    max = 2,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = true,
    category = "Evocity Criminals",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end
})
TEAM_MEDIC = DarkRP.createJob("Medic", {
    color = Color(21, 217, 99, 255),
    model = {"models/player/kleiner.mdl"},
    description = [[With your medical knowledge you work to restore players to full health.
        Without a medic, people cannot be healed.
        Left click with the Medical Kit to heal other players.
        Right click with the Medical Kit to heal yourself.]],
    weapons = {"med_kit"},
    command = "medic",
    max = 3,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Evocity Citizens",
    medic = true,
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "A Medic was killed!")
    end
})
TEAM_POLICE = DarkRP.createJob("Police Officer", {
    color = Color(0, 38, 235, 255),
    model = {
        "models/player/nypd/male_02.mdl",
        "models/player/nypd/male_04.mdl",
        "models/player/nypd/male_05.mdl",
        "models/player/nypd/male_06.mdl",
        "models/player/nypd/male_07.mdl",
        "models/player/nypd/male_08.mdl",
        "models/player/nypd/male_09.mdl"
    },
    description = [[The protector of every citizen that lives in the city.
        You have the power to arrest criminals and protect innocents.
        Hit a player with your arrest baton to put them in jail.
        Bash a player with a stunstick and they may learn to obey the law.
        The Battering Ram can break down the door of a criminal, with a warrant for their arrest.
        The Battering Ram can also unfreeze frozen props (if enabled).
        Type /wanted <name> to alert the public to the presence of a criminal.]],
    weapons = {"arrest_stick", "unarrest_stick", "m9k_hk45", "door_ram", "weaponchecker"},
    command = "policeofficer",
    max = 5,
    salary = 200,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "A Police Officer was K.I.A.")
    end
})
TEAM_PCHIEF = DarkRP.createJob("Police Chief", {
    color = Color(66, 0, 255, 255),
    model = {"models/player/nypd/male_02.mdlmodels/player/nypd/male_04.mdlmodels/player/nypd/male_05.mdlmodels/player/nypd/male_06.mdlmodels/player/nypd/male_07.mdlmodels/player/nypd/male_08.mdlmodels/player/nypd/male_09.mdl"},
    description = [[You are the leader of the whole police force.
					You must keep all the police in order.
					You can demote officers if they aren't following the rules.]],
    weapons = {"arrest_stick", "unarrest_stick", "m9k_hk45", "door_ram", "weaponchecker", "m9k_mossberg590"},
    command = "policechief",
    max = 1,
    salary = 325,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
    NeedToChangeFrom = TEAM_POLICE,
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "The Police Chief was K.I.A!")
    end
})
TEAM_FBI = DarkRP.createJob("FBI", {
    color = Color(0, 44, 255, 255),
    model = {
        "models/player/odessa.mdl",
        "models/player/mossman_arctic.mdl",
        "models/player/magnusson.mdl"
    },
    description = [[You are the FBI! You are the big guns, you only catch the biggest, baddest criminals.
	What you say goes and it's final! You also assist Secret Service if you are not working on any jobs.]],
    weapons = {"arrest_stick", "unarrest_stick", "m9k_hk45", "door_ram", "weaponchecker", "m9k_mossberg590"},
    command = "FBI",
    max = 5,
    salary = 500,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
    NeedToChangeFrom = TEAM_POLICE,
	ammo = {
        ["pistol"] = 60,
		["shotgun"] = 15
    },
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(1)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "An FBI agent was K.I.A.")
    end
})
TEAM_SWAT = DarkRP.createJob("SWAT", {
    color = Color(0, 44, 255, 255),
    model = {
        "models/player/barney.mdl",
        "models/player/police.mdl",
        "models/player/police_fem.mdl",
        "models/player/gasmask.mdl",
        "models/player/swat.mdl",
        "models/player/riot.mdl",
        "models/player/urban.mdl"
    },
    description = [[You are... The last resort, you handle riots and murder.
	With this in mind you may also be called to jobs such as drug busts or kidnappings!]],
    weapons = {"arrest_stick", "unarrest_stick", "m9k_m92beretta", "m9k_ump45", "door_ram", "weaponchecker"},
    command = "SWAT",
    max = 5,
    salary = 350,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
    NeedToChangeFrom = TEAM_POLICE,
    ammo = {
        ["pistol"] = 60
    },
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(100)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "A SWAT was K.I.A.")
    end
})
TEAM_MAYOR = DarkRP.createJob("Mayor", {
    color = Color(0, 44, 255, 255),
    model = {"models/player/breen.mdl"},
    description = [[The Mayor of the city creates laws to govern the city.
    If you are the mayor you may create and accept warrants.
    Type /wanted <name>  to warrant a player.
    Type /jailpos to set the Jail Position.
    Type /lockdown initiate a lockdown of the city.
    Everyone must be inside during a lockdown.
    The cops patrol the area.
    /unlockdown to end a lockdown]],
    weapons = {},
    command = "mayor",
    max = 1,
    salary = 1500,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
    mayor = true,
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(149)
        ply:SetHealth(149)
        ply:SetArmor(100)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "The Mayor was killed")
    end
})
TEAM_HOBO = DarkRP.createJob("Hobo", {
    color = Color(0, 44, 255, 255),
    model = {"models/player/corpse1.mdl"},
    description = [[The lowest member of society. Everybody laughs at you.
        You have no home.
        Beg for your food and money
        Sing for everyone who passes to get money
        Make your own wooden home somewhere in a corner or outside someone else's door]],
    weapons = {"weapon_bugbait"},
    command = "hobo",
    max = 5,
    salary = 0,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Evocity Citizens",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_FIRE = DarkRP.createJob("Fire Firefighter", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/Group03m"},
    description = [[You are a Fireman. Fight fires with your fire extinguisher, or attach a fire hose to a hydrant. Protect the city from fires before it gets too out of control.]],
    weapons = {"Weapon_extinguisher"},
    command = "fireman",
    max = 3,
    salary = 350,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
    NeedToChangeFrom = TEAM_POLICE,
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(50)
    end
})
DarkRP.createDemoteGroup("Cops", {TEAM_POLICE, TEAM_CHIEF, TEAM_FBI, TEAM_SWAT})
DarkRP.createDemoteGroup("Evocity Criminals", {TEAM_GANG, TEAM_MOB})
DarkRP.addHitmanTeam(TEAM_MOB)
GAMEMODE.DefaultTeam = TEAM_CITIZEN