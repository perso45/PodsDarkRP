-----------------------------------------------
-- Categories --

DarkRP.createCategory{
    name = "Meth",
    categorises = "entities",
    startExpanded = true,
    color = Color(0, 107, 0, 255),
    canSee = function(ply) return table.HasValue({TEAM_METH}, ply:Team()) end,
    sortOrder = 1,
}

DarkRP.createCategory{
	name = "Entities",
	catagorises = "entities",
	startExpanded = true,
	color = Color(0, 0, 204, 0),
	sortOrder = 2,
}

DarkRP.createCategory{
	name = "Donator Entities",
	catagorises = "entities",
	startExpanded = true,
	color = Color(0, 255, 255, 0),
	canSee = function(ply) return ply:CheckGroup("vip", "vip_gold") or ply:IsAdmin() end, -- May not be the right code, see for fix (maybe) > http://wiki.darkrp.com/index.php/Donator_Job_configuration
	sortOrder = 3,
}
	
-----------------------------------------------
-- Entities --
DarkRP.createCategory("Small Health Kit", {
	ent = "item_healthvial",
	model = "models/healthvial.mdl",
		category = "Entities",
	price = ,
	max = 3,
	cmd = "buysmallhealth",
})

DarkRP.createCategory("Large Health Kit", {
	ent = "item_healthkit",
	model = "models/Items/HealthKit.mdl",
		category = "Donator Entities",
	price = ,
	max = 3,
	cmd = "buylargehealth",
})

DarkRP.createCategory("Armor", {
	ent = "item_battery",
	model = "models/Items/battery.mdl",
		category = "Entities",
	price = ,
	max = 3,
	cmd = "buyarmor",
})

--DarkRP.createCategory("Radio", {
--	ent = "",
--	model = "",
--		category = "",
--	price = ,
--	max = ,
--	cmd = "buy",
--})

DarkRP.createCategory("", {
	ent = "",
	model = "",
		category = "",
	price = ,
	max = ,
	cmd = "buy",
})

DarkRP.createEntity("Gas Canister", {
	ent = "eml_gas",
	model = "models/props_c17/canister01a.mdl",
        category = "Meth",
	price = 0,
	max = 2,
	cmd = "buygascanister",
	customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Liquid Iodine", {
	ent = "eml_iodine",
	model = "models/props_lab/jar01b.mdl",
        category = "Meth",
	price = 0,
	max = 5,
	cmd = "buyiodine",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Jar", {
	ent = "eml_jar",
	model = "models/props_lab/jar01a.mdl",
        category = "Meth",
	price = 0,
	max = 1,
	cmd = "buyjar",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Muriatic Acid", {
	ent = "eml_macid",
	model = "models/props_junk/garbage_plasticbottle001a.mdl",
        category = "Meth",
	price = 0,
	max = 5,
	cmd = "buymacid",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Pot", {
	ent = "eml_pot",
	model = "models/props_c17/metalPot001a.mdl",
        category = "Meth",
	price = 0,
	max = 1,
	cmd = "buypot",
        allowed = {TEAM_METH}
})

DarkRP.createEntity("Special Pot", {
	ent = "eml_spot",
	model = "models/props_c17/metalPot001a.mdl",
        category = "Meth",
	price = 0,
	max = 1,
	cmd = "buyspot",
	customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Stove", {
	ent = "eml_stove",
	model = "models/props_c17/furnitureStove001a.mdl",
        category = "Meth",
	price = 0,
	max = 1,
	cmd = "buystove",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Liquid Sulfur", {
	ent = "eml_sulfur",
	model = "models/props_lab/jar01b.mdl",
        category = "Meth",
	price = 0,
	max = 5,
	cmd = "buysulfur",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Water", {
	ent = "eml_water",
	model = "models/props_junk/garbage_plasticbottle003a.mdl",
        category = "Meth",
	price = 0,
	max = 5,
	cmd = "buywater",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})