-- Standard Ammos --

DarkRP.createAmmoType("smg1", {
    name = "SMG Ammo",
    model = "models/Items/BoxMRounds.mdl",
    price = 50,
    amountGiven = 30,
	category = "SMG"
})

DarkRP.createAmmoType("ar2", {
	name = "Assualt Rifle Ammo",
	model = "models/Items/BoxMRounds.mdl",
	price = 50,
	amountGiven = 30,
	category = "Assault Rifle"
})
DarkRP.createAmmoType("pistol", {
	name = "Pistol Ammo",
	model = "models/Items/BoxSRounds.mdl",
	price = 35,
	amountGiven = 30,
	category = "Pistol"
})

DarkRP.createAmmoType("357", {
	name = "357 Ammo",
	model = "models/Items/357ammo.mdl",
	price = 35,
	amountGiven = 30,
	category = "Revolver/357"
})

DarkRP.createAmmoType("buckshot", {
	name = "Shotgun Ammo",
	model = "models/Items/BoxBuckshot.mdl",
	price = 50,
	amountGiven = 15,
	Category = "Shotgun"
})

-----------------------------------------------
-- Ammo Crates --

DarkRP.createAmmoType("smg1", {
    name = "SMG Ammo Crate",
    model = "models/Items/ammocrate_smg1.mdl",
    price = 200,
    amountGiven = 150,
	category = "SMG"
})

DarkRP.createAmmoType("ar2", {
	name = "Assualt Rifle Ammo Crate",
	model = "models/Items/ammocrate_ar2.mdl",
	price = 200,
	amountGiven = 150,
	category = "Assault Rifle"
})

-----------------------------------------------
-- Categories --

DarkRP.createCategory{
    name = "SMG",
    categorises = "ammo",
    startExpanded = true,
    color = Color(0, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 1
}

DarkRP.createCategory{
    name = "Assault Rifle",
    categorises = "ammo",
    startExpanded = true,
    color = Color(0, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 2
}

DarkRP.createCategory{
    name = "Pistol",
    categorises = "ammo",
    startExpanded = true,
    color = Color(0, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 3
}

DarkRP.createCategory{
    name = "Revolver/357",
    categorises = "ammo",
    startExpanded = true,
    color = Color(0, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 4
}

DarkRP.createCategory{
    name = "Shotgun",
    categorises = "ammo",
    startExpanded = true,
    color = Color(0, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 5
}