AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include('shared.lua')
include("../../config_ekc.lua")

util.PrecacheSound("buttons/button14.wav")
util.PrecacheSound("buttons/button9.wav")
util.PrecacheSound("buttons/button11.wav")
util.PrecacheSound("buttons/button15.wav")

function ENT:Initialize()
	self.Entity:SetModel( "models/props_lab/keypad.mdl" )
	self.Entity:PhysicsInit( SOLID_VPHYSICS )
	self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
	self.Entity:SetSolid( SOLID_VPHYSICS )

	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end
end

function ENT:PreEntityCopy()
	duplicator.StoreEntityModifier(self, "keypaddupe", {
		pass = self.Entity.Pass,
		length1 = self:GetNWInt("keypad_length1"),
		length2 = self:GetNWInt("keypad_length2"),
		keygroup1 = self:GetNWInt("keypad_keygroup1"),
		keygroup2 = self:GetNWInt("keypad_keygroup2"),
		secure = self:GetNWBool("keypad_secure")
	})
end

local function restoreKeypadSettings(ply, ent, data)
	ent.Pass = data.pass
	ent:SetNWEntity("keypad_owner", ply)
	ent:SetNWInt("keypad_length1", data.length1)
	ent:SetNWInt("keypad_length2", data.length2)
	ent:SetNWInt("keypad_keygroup1", data.keygroup1)
	ent:SetNWInt("keypad_keygroup2", data.keygroup2)
	ent:SetNWBool("keypad_secure", data.secure)
end
duplicator.RegisterEntityModifier( "keypaddupe", restoreKeypadSettings )

function ENT:SetPassword(Pass)
	if tonumber(Pass) and (Pass > 0 and Pass <= 9999) then
		self.Entity.Pass = util.CRC(Pass)
	end
end

function ENT:TestPassword()
	return self.Entity.Pass == util.CRC(tonumber(self:GetNWString("keypad_num")) or "1")
end

function ENT:Success()
	if IsValid(self:GetNWEntity("keypad_owner")) and self:GetNWEntity("keypad_owner"):IsPlayer() and self:GetNWInt("keypad_keygroup1") >= -1 then
		self:SetNWBool("keypad_access", true)
		self:EmitSound("buttons/button9.wav")
		if self:GetNWInt("keypad_keygroup1") ~= -1 then
			numpad.Activate( self:GetNWEntity("keypad_owner"), self:GetNWInt("keypad_keygroup1"), false )
			timer.Create("keypad"..tostring(self:EntIndex()).."deactivatenumpadkey", self:GetNWInt("keypad_length1"), 1, function () 
				if IsValid(self) and IsValid(self:GetNWEntity("keypad_owner")) and self:GetNWEntity("keypad_owner"):IsPlayer() then 
					numpad.Deactivate( self:GetNWEntity("keypad_owner"), self:GetNWInt("keypad_keygroup1"), false ) 
				end 
			end)
		end
		self:SetNWBool("keypad_showaccess", true)
		timer.Simple(2, function()
			if (IsValid(self)) then
				self:SetNWString("keypad_num", "")
				self:SetNWBool("keypad_showaccess", false)
			end
		end)
	end
end

function ENT:Fail()
	if IsValid(self:GetNWEntity("keypad_owner")) and self:GetNWEntity("keypad_owner"):IsPlayer() and self:GetNWInt("keypad_keygroup2") >= -1 then
		self:SetNWBool("keypad_access", false)
		self:EmitSound("buttons/button11.wav")
		if self:GetNWInt("keypad_keygroup2") ~= -1 then
			numpad.Activate( self:GetNWEntity("keypad_owner"), self:GetNWInt("keypad_keygroup2"), false )
			timer.Create("keypad"..tostring(self:EntIndex()).."deactivatenumpadkey", self:GetNWInt("keypad_length2"), 1, function () 
				if IsValid(self) and IsValid(self:GetNWEntity("keypad_owner")) and self:GetNWEntity("keypad_owner"):IsPlayer() then 
					numpad.Deactivate( self:GetNWEntity("keypad_owner"), self:GetNWInt("keypad_keygroup2"), false ) 
				end 
			end)
		end
		self:SetNWBool("keypad_showaccess", true)
		timer.Simple(2, function()
			if (IsValid(self)) then
				self:SetNWString("keypad_num", "")
				self:SetNWBool("keypad_showaccess", false)
			end
		end)
	end
end

function ENT:Break()
	self:SetNWBool("keypad_broken", true)
	umsg.Start("keypad_break")
		umsg.Entity(self)
	umsg.End()
	timer.Create("keypad"..tostring(self:EntIndex()).."restore", math.random(DelMods.cracker.min_break_time, DelMods.cracker.max_break_time), 1, function()
		if IsValid(self) then
			self:SetNWBool("keypad_broken", false)
		end
	end)
end

local function KeypadCommand(ply, cmd, args)
	if not args[1] or not args[2] then return end
	local keypad = ents.GetByIndex(args[1])
	if not IsValid(keypad) or not keypad:GetClass() == "sent_keypad" then return end

	if keypad:GetNWBool("keypad_showaccess") or keypad:GetNWBool("keypad_broken") then return end
	if ((ply:GetShootPos() - keypad:GetPos()):Length() > 50) then return end
	if (args[2] == "reset") then
		keypad:SetNWString("keypad_num", "")
		keypad:EmitSound("buttons/button14.wav")
	elseif (args[2] == "accept") then
		if (keypad:TestPassword()) then
			keypad:Success()
		else
			keypad:Fail()
		end
	else
		if tonumber(args[2]) and (tonumber(args[2]) >= 1) and (tonumber(args[2]) <= 9) and keypad:GetNWString("keypad_num"):len() < 4 then
			keypad:SetNWString("keypad_num", keypad:GetNWString("keypad_num")..tostring(args[2]))
			keypad:EmitSound("buttons/button15.wav")
		end
	end
end
concommand.Add("gmod_keypad", KeypadCommand)
