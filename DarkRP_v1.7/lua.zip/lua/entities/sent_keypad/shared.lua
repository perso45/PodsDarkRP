ENT.Type			= "anim"
ENT.Base			= "base_gmodentity"

ENT.PrintName		= "Keypad"
ENT.Author			= "Robbis_1 (Killer HAHA), updated & fixed by Dellkan"
ENT.Contact			= "Robbis_1 at Facepunch Studios"
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.Spawnable		= false
ENT.AdminSpawnable	= false