-----------------------------------------------
-- Categories --

DarkRP.createCategory{
	name = "Rifles",
	categorises = "shipments",
	startExpanded = true,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return table.HasValue({TEAM_GUN}, ply:Team()) end,
	sortOrder = 1
}

DarkRP.createCategory{
	name = "Shotguns",
	categorises = "shipments",
	startExpanded = true,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return table.HasValue({TEAM_GUN}, ply:Team()) end,
	sortOrder = 2
}

DarkRP.createCategory{
	name = "Pistols",
	categorises = "shipments",
	startExpanded = true,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return table.HasValue({TEAM_GUN}, ply:Team()) end,
	sortOrder = 3
}

DarkRP.createCategory{
	name = "Sub Machine Guns",
	categorises = "shipments",
	startExpanded = true,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return table.HasValue({TEAM_GUN}, ply:Team()) end,
	sortOrder = 4
}

DarkRP.createCategory{
	name = "Sniper Rifles",
	categorises = "shipments",
	startExpanded = true,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return table.HasValue({TEAM_GUN}, ply:Team()) end,
	sortOrder = 5
}
DarkRP.createCategory{
    name = "Other",
    categorises = "shipments",
    startExpanded = true,
    color = Color(0, 107, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 6
}

-----------------------------------------------
-- Other --

DarkRP.createShipment("Enhanced Keypad Cracker", {
    model = "models/weapons/w_c4.mdl",
    entity = "sent_keypad",
    amount = 10,
    price = 5000,
    separate = true,
    pricesep = 500,
    noship = false,
    category = "Other",
    allowed = {TEAM_GANG,
			   TEAM_MOB, 
			   TEAM_SWAT}
})

DarkRP.createShipment("Lockpick", {
    model = "models/weapons/w_c4.mdl",
    entity = "lockpick",
    amount = 10,
    price = 6000,
    separate = true,
    pricesep = 600,
    noship = false,
    category = "Other",
    allowed = {TEAM_GANG,
			   TEAM_MOB, 
			   TEAM_SWAT}
})
-----------------------------------------------
-- Rifles --

DarkRP.createShipment("AK47", {
	model = "models/weapons/w_tct_ak47.mdl",
	entity = "m9k_ak47",
	price = 120000,
	amount = 10,
	separate = true,
	pricesep = 12500,
	noship = false,
	category = "Rifles",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("ACR", {
	model = "models/weapons/w_masada_acr.mdl",
	entity = "m9k_acr",
	price = 160000,
	amount = 10,
	separate = true,
	pricesep = 16500,
	noship = false,
	category = "Rifles",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("FN FAL", {
	model = "models/weapons/w_fn_fal.mdl",
	entity = "m9k_fal",
	price = 200000,
	amount = 10,
	separate = true,
	pricesep = 20500,
	noship = false,
	category = "Rifles",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("FAMAS", {
	model = "models/weapons/w_tct_famas.mdl",
	entity = "m9k_famas",
	price = 180000,
	amount = 10,
	separate = true,
	pricesep = 18500,
	noship = false,
	category = "Rifles",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("AUG 43", {
	model = "models/weapons/w_auga3.mdl",
	entity = "m9k_auga3",
	price = 175000,
	amount = 10,
	separate = true,
	pricesep = 17500,
	noship = false,
	category = "Rifles",
	allowed = {TEAM_GUN}
})

-----------------------------------------------
-- Pistols --

DarkRP.createShipment("Colt 1911", {
	model = "models/weapons/s_dmgf_co1911.mdl",
	entity = "m9k_colt1911",
	price = 15000,
	amount = 10,
	separate = true,
	pricesep = 1500,
	noship = false,
	category = "Pistols",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("Colt Python", {
	model = "models/weapons/w_colt_python.mdl",
	entity = "m9k_coltpython",
	price = 20000,
	amount = 10,
	separate = true,
	pricesep = 2500,
	noship = false,
	category = "Pistols",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("Desert Eagle", {
	model = "models/weapons/w_tcom_deagle.mdl",
	entity = "m9k_deagle",
	price = 30000,
	amount = 10,
	separate = true,
	pricesep = 3500,
	noship = false,
	category = "Pistols",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("Glock 18", {
	model = "models/weapons/w_tcom_deagle.mdl",
	entity = "m9k_deagle",
	price = 25000,
	amount = 10,
	separate = true,
	pricesep = 3000,
	noship = false,
	category = "Pistols",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("Luger", {
	model = "models/weapons/w_luger_p08.mdl",
	entity = "m9k_luger",
	price = 35000,
	amount = 10,
	separate = true,
	pricesep = 3500,
	noship = false,
	category = "Pistols",
	allowed = {TEAM_GUN}
})

-----------------------------------------------
-- Shotguns --

DarkRP.createShipment("Ithaca M37", {
	model = "models/weapons/w_ithaca_m37.mdl",
	entity = "m9k_thacam37",
	price = 40000,
	amount = 10,
	separate = true,
	pricesep = 4500,
	noship = false,
	category = "Shotguns",
	allowed = {TEAM_GUN}
})

-----------------------------------------------
-- Sniper Rifles --

DarkRP.createShipment("AI AW50", {
	model = "models/weapons/w_acc_int_aw50.mdl",
	entity = "m9k_aw50",
	price = 45000,
	amount = 10,
	separate = false,
	pricesep = 999999999,
	noship = false,
	category = "Sniper Rifles",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("PSG-1", {
	model = "models/weapons/w_rhk_psg1.mdl",
	entity = "m9k_psg1",
	price = 50000,
	amount = 10,
	separate = false,
	pricesep = 0,
	noship = false,
	category = "Sniper Rifles",
	allowed = {TEAM_GUN}
})

-----------------------------------------------
-- Sub-Machine Guns --

DarkRP.createShipment("P90", {
	model = "models/weapons/w_fn_p90.mdl",
	entity = "m9k_smgp90",
	price = 40000,
	amount = 10,
	separate = true,
	pricesep = 4500,
	noship = false,
	category = "Sub Machine Guns",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("MP7", {
	model = "models/weapons/w_mp7_silenced.mdl",
	entity = "m9k_mp7",
	price = 45000,
	amount = 10,
	separate = true,
	pricesep = 5000,
	noship = false,
	category = "Sub Machine Guns",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("TEC-9", {
	model = "models/weapons/w_intratec_tec9.mdl",
	entity = "mpk_tec9",
	price = 35000,
	amount = 10,
	separate = true,
	pricesep = 4000,
	noship = false,
	category = "Sub Machine Guns",
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("KAC PDW", {
	model = "models/weapons/w_kac_pdw.mdl",
	entity = "m9k_kac_pdw",
	price = 45000,
	amount = 10,
	separate = true,
	pricesep = 5000,
	noship = false,
	category = "Sub Machine Guns",
	allowed = {TEAM_GUN}
})
