-----------------------------------------------
-- Categories --

DarkRP.createCategory{
    name = "Meth",
    categorises = "entities",
    startExpanded = true,
    color = Color(0, 107, 0, 255),
    canSee = function(ply) return table.HasValue({TEAM_METH}, ply:Team()) end,
    sortOrder = 1,
}

DarkRP.createCategory{
	name = "Cocaine",
	categorises = "entities",
	startExpanded = true,
	color = Color(0, 255, 255, 255),
	canSee = function(ply) return table.HasValue({TEAM_COKE}, ply:Team()) end,
	sortOrder = 2,
}

DarkRP.createCategory{
	name = "LSD",
	categorises = "entities",
	startExpanded = true,
	color = Color(0, 255, 0, 255),
	canSee = function(ply) return table.HasValue({TEAM_LSD}, ply:Team()) end,
	sortOrder = 3,
}

DarkRP.createCategory{
	name = "Advanced Meth",
	categorises = "entities",
	startExpanded = true,
	color = Color(0, 0, 0, 0),
	canSee = function(ply) return table.HasValue({TEAM_AMETH}, ply:Team()) end,
	sortOrder = 4,
}

DarkRP.createCategory{
	name = "Bitcoin Miners",
	categorises = "entities",
	startExpanded = true,
	color = Color(0, 255, 0, 0),
	canSee = function(ply) return table.HasValue({TEAM_BIT}, ply:Team()) end,
	sortOrder = 5,
}

DarkRP.createCategory{
	name = "Businessman",
	categorises = "entities",
	startExpanded = true,
	color = Color(0, 0, 0, 255),
	canSee = function(ply) return table.HasValue({TEAM_WORK}, ply:Team()) end,
	sortOrder = 6,
}

DarkRP.createCategory{
	name = "Entities",
	categorises = "entities",
	startExpanded = true,
	color = Color(0, 0, 204, 0),
	sortOrder = 665,
}

DarkRP.createCategory{
	name = "Donator Entities",
	categorises = "entities",
	startExpanded = true,
	color = Color(0, 255, 255, 0),6
	sortOrder = 666,
}
	
-----------------------------------------------
-- Entities --
DarkRP.createEntity("Small Health Kit", {
	ent = "item_healthvial",
	model = "models/healthvial.mdl",
		category = "Entities",
	price = ,
	max = 3,
	cmd = "buysmallhealth",
})

DarkRP.createEntity("Large Health Kit", {
	ent = "item_healthkit",
	model = "models/Items/HealthKit.mdl",
		category = "Donator Entities",
	price = ,
	max = 3,
	cmd = "buylargehealth",
	customCheck = function(ply) return
        table.HasValue({"superadmin", "admin", "Owner", "VIP", "VIP Gold"}, ply:GetNWString("usergroup"))
    end,
})

DarkRP.createEntity("Armor", {
	ent = "item_battery",
	model = "models/Items/battery.mdl",
		category = "Entities",
	price = ,
	max = 3,
	cmd = "buyarmor",
})

--DarkRP.createEntity("", {
--	ent = "",
--	model = "",
--		category = "",
--	price = ,
--	max = ,
--	cmd = "buy",
--})

-----------------------------------------------
-- Meth --
DarkRP.createEntity("Gas Canister", {
	ent = "eml_gas",
	model = "models/props_c17/canister01a.mdl",
        category = "Meth",
	price = 750,
	max = 2,
	cmd = "buygascanister",
	customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Liquid Iodine", {
	ent = "eml_iodine",
	model = "models/props_lab/jar01b.mdl",
        category = "Meth",
	price = 100,
	max = 5,
	cmd = "buyiodine",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Jar", {
	ent = "eml_jar",
	model = "models/props_lab/jar01a.mdl",
        category = "Meth",
	price = 250,
	max = 1,
	cmd = "buyjar",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Muriatic Acid", {
	ent = "eml_macid",
	model = "models/props_junk/garbage_plasticbottle001a.mdl",
        category = "Meth",
	price = 100,
	max = 5,
	cmd = "buymacid",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Pot", {
	ent = "eml_pot",
	model = "models/props_c17/metalPot001a.mdl",
        category = "Meth",
	price = 1000,
	max = 1,
	cmd = "buypot",
        allowed = {TEAM_METH}
})

DarkRP.createEntity("Special Pot", {
	ent = "eml_spot",
	model = "models/props_c17/metalPot001a.mdl",
        category = "Meth",
	price = 2500,
	max = 1,
	cmd = "buyspot",
	customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Stove", {
	ent = "eml_stove",
	model = "models/props_c17/furnitureStove001a.mdl",
        category = "Meth",
	price = 5000,
	max = 1,
	cmd = "buystove",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Liquid Sulfur", {
	ent = "eml_sulfur",
	model = "models/props_lab/jar01b.mdl",
        category = "Meth",
	price = 100,
	max = 5,
	cmd = "buysulfur",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

DarkRP.createEntity("Water", {
	ent = "eml_water",
	model = "models/props_junk/garbage_plasticbottle003a.mdl",
        category = "Meth",
	price = 50,
	max = 5,
	cmd = "buywater",
    customCheck = function(ply) return
        table.HasValue({TEAM_METH}, ply:Team())
    end,
})

-----------------------------------------------
-- Cocaine --
DarkRP.createEntity("Collect Box", {
	ent = "ecl_leafbox",
	model = "models/props_junk/cardboard_box004a.mdl",
		category = "Cocaine",
	price = 1000,
	max = 1,
	cmd = "buycollectbox",
})

DarkRP.createEntity("Kerosin", {
	ent = "ecl_kerosin",
	model = "models/props_junk/metal_paintcan001a.mdl",
		category = "Cocaine",
	price = 1500,
	max = 2,
	cmd = "buykerosin",
})

DarkRP.createEntity("Water Bucket", {
	ent = "ecl_drafted",
	model = "models/props_junk/plasticbucket001a.mdl",
		category = "Cocaine",
	price = 1000,
	max = 4,
	cmd = "buywaterbucket",
})

DarkRP.createEntity("Sulfuric Acid", {
	ent = "ecl_sulfuric_acid",
	model = "models/props_junk/garbage_milkcarton001a.mdl",
		category = "Cocaine",
	price = 1500,
	max = 1,
	cmd = "buysulfuricacid",
})

DarkRP.createEntity("Pot", {
	ent = "ecl_pot",
	model = "models/props_c17/metalPot001a.mdl",
		category = "Cocaine",
	price = 250,
	max = 1,
	cmd = "buycokepot",
})

DarkRP.createEntity("Stove", {
	ent = "ecl_stove",
	model = "models/srcocainelab/portablestove.mdl",
		category = "Cocaine",
	price = 5000,
	max = 1,
	cmd = "buycokestove",
})

DarkRP.createEntity("Stove Gas", {
	ent = "ecl_gas",
	model = "models/srcocainelab/gascan.mdl",
		category = "Cocaine",
	price = 750,
	max = 2,
	cmd = "buystovegas",
})

DarkRP.createEntity("Soaking Gas", {
	ent = "ecl_gasoline",
	model = "",
		category = "Cocaine",
	price = 1500,
	max = 1,
	cmd = "buygasoline",
})

DarkRP.createEntity("Plant Pot", {
	ent = "ecl_plant_pot",
	model = "models/props_junk/metalgascan.mdl",
		category = "Cocaine",
	price = 500,
	max = 10,
	cmd = "buyplantpot",
})

DarkRP.createEntity("Cocoa Seed", {
	ent = "ecl_seed",
	model = "models/spitball_small.mdl",
		category = "Cocaine",
	price = 1000,
	max = 10,
	cmd = "buycocoaseed",
})
-----------------------------------------------
-- Enhanced Meth --
DarkRP.createEntity("Chemical Tank", {
	ent = "hr_cm_tank",
	model = "models/props_wasteland/laundry_washer001a.mdl",
		category = "Advanced Meth",
	price = 5000,
	max = 1,
	cmd = "buytank",
})

DarkRP.createEntity("Aluminium Box", {
	ent = "hr_cm_aluminum_box",
	model = "models/props_junk/cardboard_box001a.mdl",
		category = "Advanced Meth",
	price = 1000,
	max = 3,
	cmd = "buyaluminium",
})

DarkRP.createEntity("Sulfur Trioxide Box", {
	ent = "hr_cm_sulfurd_box",
	model = "models/props_junk/cardboard_box001a.mdl",
		category = "Advanced Meth",
	price = 1500,
	max = 3,
	cmd = "buytrioxide",
})

DarkRP.createEntity("Red Phosphorus Box", {
	ent = "hr_cm_redp_box",
	model = "models/props_junk/cardboard_box001a.mdl",
		category = "Advanced Meth",
	price = 1500,
	max = 3,
	cmd = "buyrphosphorus",
})

DarkRP.createEntity("Advanced Stove", {
	ent = "hr_cm_stove",
	model = "models/props_wasteland/kitchen_stove001a.mdl",
		category = "Advanced Meth",
	price = 3000,
	max = 1,
	cmd = "buyastove",
})

DarkRP.createEntity("Master Pot", {
	ent = "hr_cm_potia",
	model = "models/props_c17/metalPot001a.mdl",
		category = "Advanced Meth",
	price = 1000,
	max = 1,
	cmd = "buympot",
})

DarkRP.createEntity("Sulfur Pot", {
	ent = "hr_cm_potwd",
	model = "models/props_interiors/pot02a.mdl",
		category = "Advanced Meth",
	price = 750,
	max = 1,
	cmd = "buyspot",
})

DarkRP.createEntity("Red Phosphorus Pot", {
	ent = "hr_cm_potwr",
	model = "models/props_interiors/pot02a.mdl",
		category = "Advanced Meth",
	price = 750,
	max = 1,
	cmd = "buyrpot",
})

DarkRP.createEntity("Chemical Glass", {
	ent = "hr_cm_glass",
	model = "models/props_junk/garbage_glassbottle002a.mdl",
		category = "Advanced Meth",
	price = 1000,
	max = 3,
	cmd = "buychemicalglass",
})

DarkRP.createEntity("Methylamine", {
	ent = "hr_cm_methylamine",
	model = "models/props_c17/oildrum001.mdl",
		category = "Advanced Meth",
	price = 500,
	max = 2,
	cmd = "buymethylamine",
})

DarkRP.createEntity("Cyfluthrin", {
	ent = "hr_cm_cyfluthrin",
	model = "models/props_junk/metalgascan.mdl",
		category = "Advanced Meth",
	price = 500,
	max = 3,
	cmd = "buycyfluthrin",
})

DarkRP.createEntity("Water", {
	ent = "hr_cm_water",
	model = "models/props_junk/garbage_milkcarton001a.mdl",
		category = "Advanced Meth",
	price = 500,
	max = 2,
	cmd = "buywater",
})

-----------------------------------------------
-- Bitcoin --
DarkRP.createEntity("Server Rack", {
	ent = "bm2_bitminer_rack",
	model = "",
		category = "Bitcoin Miners",
	price = 10000,
	max = 3,
	cmd = "buyminerrack",
})

DarkRP.createEntity("Miner Server", {
	ent = "bm2_bitminer_server",
	model = "",
		category = "Bitcoin Miners",
	price = 1000,
	max = 24,
	cmd = "buyserver",
})

DarkRP.createEntity("Generator", {
	ent = "bm2_generator",
	model = "",
		category = "Bitcoin Miners",
	price = 2500,
	max = 3,
	cmd = "buygenerator",
})

DarkRP.createEntity("Fuel", {
	ent = "bm2_fuel",
	model = "",
		category = "Bitcoin Miners",
	price = 500,
	max = 5,
	cmd = "buyfuel",
})

DarkRP.createEntity("Power Cord", {
	ent = "bm2_power_lead",
	model = "",
		category = "Bitcoin Miners",
	price = 100,
	max = 3,
	cmd = "buypowercord",
})

DarkRP.createEntity("Extension Lead", {
	ent = "bm2_extention_lead",
	model = "",
		category = "Bitcoin Miners",
	price = 100,
	max = 2,
	cmd = "buypowerlead",
})

DarkRP.createEntity("Big Bitminer", {
	ent = "bm2_bitminer_1",
	model = "",
		category = "Bitcoin Miners",
	price = 8500,
	max = 3,
	cmd = "buybigminer",
})

DarkRP.createEntity("Small Bitminer", {
	ent = "bm2_bitminer_2",
	model = "",
		category = "Bitcoin Miners",
	price = 5000,
	max = 3,
	cmd = "buysmallminer",
})

-----------------------------------------------
-- Businessman --
DarkRP.createEntity("Good Box", {
	ent = "sb_good_box",
	model = "models/props_junk/cardboard_box001a.mdl",
		category = "Businessman",
	price = 250,
	max = 3,
	cmd = "buygoodbox",
})

DarkRP.createEntity("Good Guide", {
	ent = "sb_good_guide",
	model = "models/props_lab/binderredlabel.mdl",
		category = "Businessman",
	price = 250,
	max = 3,
	cmd = "buygoodguide",
})

DarkRP.createEntity("Crime Box", {
	ent = "sb_crime_box",
	model = "models/props_junk/cardboard_box001a.mdl",
		category = "Businessman",
	price = 250,
	max = 3,
	cmd = "buycrimebox",
})

DarkRP.createEntity("Crime Guide", {
	ent = "sb_crime_guide",
	model = "models/props_lab/binderredlabel.mdl",
		category = "Businessman",
	price = 250,
	max = 3,
	cmd = "buycrimeguide",
})

DarkRP.createEntity("Worker Seat", {
	ent = "sb_wk_seat",
	model = "models/props_combine/breenchair.mdl",
		category = "Businessman",
	price = 2500,
	max = 15,
	cmd = "buyworkseat",
})

DarkRP.createEntity("Worker Area", {
	ent = "sb_wk_place",
	model = "models/props_combine/breendesk.mdl",
		category = "Businessman",
	price = 2500,
	max = 15,
	cmd = "buyworkarea",
})