ENT.Base = "base_gmodentity";
ENT.Type = "anim";

ENT.PrintName		= "Special Pot";
ENT.Category 		= "EML";
ENT.Author			= "EnnX49";

ENT.Contact    		= "";
ENT.Purpose 		= "";
ENT.Instructions 	= "" ;

ENT.Spawnable			= true;
ENT.AdminSpawnable		= true;
