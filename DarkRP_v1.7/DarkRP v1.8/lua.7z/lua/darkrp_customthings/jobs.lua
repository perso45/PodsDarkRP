DarkRP.createCategory{
    name = "Evocity Citizens",
    categorises = "jobs",
    startExpanded = true,
    color = Color(0, 107, 0, 255),
    canSee = fp{fn.Id, true},
    sortOrder = 100,
}

DarkRP.createCategory{
	name = "Evocity Police",
	categorises = "jobs",
	startExpanded = true,
	color = Color(25, 25, 170, 255),
	canSee = fp{fn.Id, true},
	setOrder = 101,
}

DarkRP.createCategory{
	name = "Court Workers",
	categorises = "jobs",
	startExpanded = true,
	color = Color(0, 204, 0, 122),
	canSee = fp{fn.Id, true},
	setOrder = 102,
}

DarkRP.createCategory{
    name = "Evocity Criminals",
    categorises = "jobs",
    startExpanded = true,
    color = Color(75, 75, 75, 255),
    canSee = fp{fn.Id, true},
    sortOrder = 105,
}

DarkRP.createCategory{
    name = "Other",
    categorises = "jobs",
    startExpanded = true,
    color = Color(0, 107, 0, 255),
    canSee = fp{fn.Id, true},
    sortOrder = 255,
}

--- Jobs ---

TEAM_CITIZEN = DarkRP.createJob("Citizen", {
    color = Color(20, 150, 20, 255),
    model = {
        "models/player/Group01/Female_01.mdl",
        "models/player/Group01/Female_02.mdl",
        "models/player/Group01/Female_03.mdl",
        "models/player/Group01/Female_04.mdl",
        "models/player/Group01/Female_06.mdl",
        "models/player/group01/male_01.mdl",
        "models/player/Group01/Male_02.mdl",
        "models/player/Group01/male_03.mdl",
        "models/player/Group01/Male_04.mdl",
        "models/player/Group01/Male_05.mdl",
        "models/player/Group01/Male_06.mdl",
        "models/player/Group01/Male_07.mdl",
        "models/player/Group01/Male_08.mdl",
        "models/player/Group01/Male_09.mdl"
    },
    description = [[The Citizen is the most basic level of society you can hold besides being a hobo. You have no specific role in city life.]],
    weapons = {},
    command = "citizen",
    max = 0,
    salary = 50,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Evocity Citizens",
})

---------------------------------------------------------
GAMEMODE.DefaultTeam = TEAM_CITIZEN
---------------------------------------------------------

TEAM_GANG = DarkRP.createJob("Gangster", {
    color = Color(255, 0, 0, 255),
    model = {
        "models/player/Group03/Female_01.mdl",
        "models/player/Group03/Female_02.mdl",
        "models/player/Group03/Female_03.mdl",
        "models/player/Group03/Female_04.mdl",
        "models/player/Group03/Female_06.mdl",
        "models/player/group03/male_01.mdl",
        "models/player/Group03/Male_02.mdl",
        "models/player/Group03/male_03.mdl",
        "models/player/Group03/Male_04.mdl",
        "models/player/Group03/Male_05.mdl",
        "models/player/Group03/Male_06.mdl",
        "models/player/Group03/Male_07.mdl",
        "models/player/Group03/Male_08.mdl",
        "models/player/Group03/Male_09.mdl"
    },
    description = [[The lowest person of crime.
        A gangster generally works for the Mobboss who runs the crime family.
        The Mob boss sets your agenda and you follow it or you might be punished.]],
    weapons = {},
    command = "gangster",
    max = 3,
    salary = 50,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Evocity Criminals",
	hasLicense = false,
})

TEAM_WEED = DarkRP.createJob("Weed Grower", {
	color = Color(0, 102, 255, 102),
	model = {"models/snoopdogg.mdl"},
	description = [[Your job is to grow some dank kush!
	Once you grow it, you can sell, smoke it, or do whatever else you want with it.
	Buy a tablet from the Weed Dealer, grow it, and sell it to the Weed Dealer.]],
	weapons = {},
	command = "weedgrower",
	max = 5,
	salary = 50,
	admin = 0,
	vote = false,
	category = "Evocity Criminals",
})

TEAM_HACK = DarkRP.createJob("Hacker", {
	color = Color(0, 0, 0, 255),
	model = {"models/Kleiner.mdl"},
	description = [[You are a hacker, you hack stuff.
	People can hire you to help raid bases!]],
	weapons = {}, -- Add keypad cracker weapon
	command = "hacker",
	max = 5,
	salary = 75,
	admin = 0,
	vote = false,
	category = "Evocity Criminals",
})

TEAM_FIX = DarkRP.createJob("Mechanic", {
	color = Color(0, 160, 160, 160),
	model = {"models/odessa.mdl"},
	description = [[You are a mechanic.
	You should open up a mechanics shop and work on cars!]],
	weapons = {nova_mechanic},
	command = "mechanic",
	max = 3,
	salary = 75,
	admin = 0,
	vote = false,
	category = "Evocity Citizens",
})

TEAM_COKE = DarkRP.createJob("Cocaine Producer", {
	color = Color(0, 255, 255, 255),
	model = {
		"models/Humans/Group02/male_02.mdl",
		"models/Humans/Group02/Male_04.mdl",
		"models/Humans/Group02/male_06.mdl",
		"models/Humans/Group02/male_08.mdl",
	},
	description = [[Time to make the cocoa!
	Cook it, clean it, move it, sell it!]],
	weapons = {},
	command = "cocaine",
	max = 5,
	salary = 50,
	admin = 0,
	vote = false,
	category = "Evocity Criminals",
})

TEAM_LSD = DarkRP.createJob("LSD Producer", {
	color = Color(0, 255, 0, 255),
	model = {"models/Barney.mdl"},
	description = [[Physcadelics are the way to go!
	It's time to get trippy, and trippier, and trippier!
	Buy the Phone from the LSD Dealer.
	Cook it and pop the paper!]],
	weapons = {},
	command = "lsd",
	max = 5,
	salary = 50,
	admin = 0,
	vote = false,
	category = "Evocity Criminals",
})

TEAM_AMETH = DarkRP.createJob("Advanced Meth Cook", {
	color = Color(0, 0, 0, 0),
	model = {"models/bloocobalt/splintercell/chemsuit_cod"},
	description = [[You cook meth, like the guys below you.
	But your meth is better. You make make rich, glass quality, baby blue meth.
	It's long and gruesome process, it's dangerous, but it's worth it...]],
	weapons = {},
	command = "ameth",
	max = 3,
	salary = 75,
	admin = 0,
	vote = false,
	category = "Evocity Criminals",
	customCheck = function(ply) return
        table.HasValue({"superadmin", "admin", "Owner", "VIP", "VIP Gold"}, ply:GetNWString("usergroup"))
    end,
})

TEAM_BIT = DarkRP.createJob("Bitcoin Miner", {
	color = Color(0, 255, 153, 51),
	model = {
	    "models/player/Group03/Female_01.mdl",
        "models/player/Group03/Female_02.mdl",
        "models/player/Group03/Female_03.mdl",
        "models/player/Group03/Female_04.mdl",
        "models/player/Group03/Female_06.mdl",
        "models/player/group03/male_01.mdl",
        "models/player/Group03/Male_02.mdl",
        "models/player/Group03/male_03.mdl",
        "models/player/Group03/Male_04.mdl",
        "models/player/Group03/Male_05.mdl",
        "models/player/Group03/Male_06.mdl",
        "models/player/Group03/Male_07.mdl",
        "models/player/Group03/Male_08.mdl",
        "models/player/Group03/Male_09.mdl"
	},
	description = [[Keep the coins comin' in!
	Build a base and start mining, you know, turn it on and sit.
	Sit and let the bitcoins come in.]],
	weapons = {},
	command = "bitcoin",
	max = 5,
	salary = 50,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Evocity Citizens",
})

TEAM_WORK = DarkRP.createJob("Businessman", {
	color = Color(0, 0, 0, 255),
	model = {"models/gman_high.mdl"},
	description = [[You are a businessman, you run a good or bad company.
	That is up for you to decide, but don't get caught.
	It could cost your job and your freedom.]],
	weapons = {},
	command = "business",
	max = 3,
	salary = 75,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Evocity Citizens",
})

TEAM_METH = DarkRP.createJob("Meth Cook", {
    color = Color(235, 255, 0, 255),
    model = {
        "models/agent_47/agent_47",
        "models/bloocobalt/splintercell/chemsuit_cod"
    },
    description = [[You are a meth cook. You cook meth and sell it. You give your profits to the Mob Boss, or else you might be punished...]],
    weapons = {},
    command = "meth",
    max = 5,
    salary = 75,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Evocity Criminals",
})

TEAM_MOB = DarkRP.createJob("Mob Boss", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gman_high.mdl"},
    description = [[The Mob boss is the boss of the criminals in the city.
        With his power he coordinates the gangsters and forms an efficient crime organization.
        He has the ability to break into houses by using a lockpick.
        The Mob boss posesses the ability to unarrest you.]],
    weapons = {"lockpick", "unarrest_stick"},
    command = "mobboss",
    max = 1,
    salary = 75,
    admin = 0,
    vote = false,
    hasLicense = true,
    candemote = true,
    category = "Evocity Criminals",
})

TEAM_HITMAN = DarkRP.createJob("Hitman", {
    color = Color(0, 0, 0, 255),
    model = {"models/player/leet.mdl"},
    description = [[You kill people, it's pretty simple.
	Someone tells you to kill someone and the rest is left up to your imagination.]],
    weapons = {"m9k_scoped_taurus"},
    command = "bountyhunter",
    max = 1,
    salary = 65,
    admin = 0,
    vote = false,
    hasLicense = true,
    candemote = true,
    category = "Evocity Criminals",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "The Hitman was killed")
    end
})

TEAM_GUN = DarkRP.createJob("Gun Dealer", {
    color = Color(21, 217, 99, 255),
    model = {"models/monk.mdl"},
    description = [[A Gun Dealer is the only person who can sell guns to other people.
        Make sure you aren't caught selling illegal firearms to the public! You might get arrested!]],
    weapons = {},
    command = "gundealer",
    max = 2,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = true,
    category = "Evocity Criminals",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end
})

TEAM_MEDIC = DarkRP.createJob("Medic", {
    color = Color(21, 217, 99, 255),
    model = {"models/player/kleiner.mdl"},
    description = [[With your medical knowledge you work to restore players to full health.
        Without a medic, people cannot be healed.
        Left click with the Medical Kit to heal other players.
        Right click with the Medical Kit to heal yourself.]],
    weapons = {"med_kit"},
    command = "medic",
    max = 3,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Evocity Citizens",
    medic = true,
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "A Medic was killed!")
    end
})

TEAM_POLICE = DarkRP.createJob("Police Officer", {
    color = Color(0, 38, 235, 255),
    model = {
        "models/player/nypd/male_02.mdl",
        "models/player/nypd/male_04.mdl",
        "models/player/nypd/male_05.mdl",
        "models/player/nypd/male_06.mdl",
        "models/player/nypd/male_07.mdl",
        "models/player/nypd/male_08.mdl",
        "models/player/nypd/male_09.mdl"
    },
    description = [[The protector of every citizen that lives in the city.
        You have the power to arrest criminals and protect innocents.
        Hit a player with your arrest baton to put them in jail.
        Bash a player with a stunstick and they may learn to obey the law.
        The Battering Ram can break down the door of a criminal, with a warrant for their arrest.
        The Battering Ram can also unfreeze frozen props (if enabled).
        Type /wanted <name> to alert the public to the presence of a criminal.]],
    weapons = {"arrest_stick", "unarrest_stick", "m9k_hk45", "door_ram", "weaponchecker"},
    command = "policeofficer",
    max = 5,
    salary = 200,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
	ammo = {
		["pistol"] = 60,
	},
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "A Police Officer was K.I.A.")
    end
})

TEAM_PCHIEF = DarkRP.createJob("Police Chief", {
    color = Color(66, 0, 255, 255),
    model = {"models/player/nypd/male_02.mdlmodels/player/nypd/male_04.mdlmodels/player/nypd/male_05.mdlmodels/player/nypd/male_06.mdlmodels/player/nypd/male_07.mdlmodels/player/nypd/male_08.mdlmodels/player/nypd/male_09.mdl"},
    description = [[You are the leader of the whole police force.
					You must keep all the police in order.
					You can demote officers if they aren't following the rules.]],
    weapons = {"arrest_stick", "unarrest_stick", "m9k_hk45", "door_ram", "weaponchecker", "m9k_mossberg590"},
    command = "policechief",
    max = 1,
    salary = 325,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
	ammo = {
		["pistol"] = 60,
		["buckshot"] = 18,
	},
    NeedToChangeFrom = TEAM_POLICE,
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(25)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "The Police Chief was K.I.A!")
    end
})

TEAM_FBI = DarkRP.createJob("FBI", {
    color = Color(0, 44, 255, 255),
    model = {
        "models/player/odessa.mdl",
        "models/player/mossman_arctic.mdl",
        "models/player/magnusson.mdl"
    },
    description = [[You are the FBI! You are the big guns, you only catch the biggest, baddest criminals.
	What you say goes and it's final! You also assist Secret Service if you are not working on any jobs.]],
    weapons = {"arrest_stick", "unarrest_stick", "m9k_hk45", "door_ram", "weaponchecker", "m9k_mossberg590"},
    command = "FBI",
    max = 5,
    salary = 500,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
    NeedToChangeFrom = TEAM_POLICE,
	ammo = {
        ["pistol"] = 60,
		["buckshot"] = 18,
    },
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(1)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "An FBI agent was K.I.A.")
    end
})

TEAM_SWAT = DarkRP.createJob("SWAT", {
    color = Color(0, 44, 255, 255),
    model = {
        "models/player/barney.mdl",
        "models/player/police.mdl",
        "models/player/police_fem.mdl",
        "models/player/gasmask.mdl",
        "models/player/swat.mdl",
        "models/player/riot.mdl",
        "models/player/urban.mdl"
    },
    description = [[You are... The last resort, you handle riots and murder.
	With this in mind you may also be called to jobs such as drug busts or kidnappings!]],
    weapons = {"arrest_stick", "unarrest_stick", "m9k_m92beretta", "m9k_striker12", "door_ram", "weaponchecker", "riot_shield"},
    command = "SWAT",
    max = 5,
    salary = 350,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
    NeedToChangeFrom = TEAM_POLICE,
    ammo = {
        ["pistol"] = 60,
		["buckshot"] = 18,
    },
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(100)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "A SWAT was K.I.A.")
    end
})

TEAM_MAYOR = DarkRP.createJob("Mayor", {
    color = Color(0, 44, 255, 255),
    model = {"models/player/breen.mdl"},
    description = [[The Mayor of the city creates laws to govern the city.
    If you are the mayor you may create and accept warrants.
    Type /wanted <name>  to warrant a player.
    Type /jailpos to set the Jail Position.
    Type /lockdown initiate a lockdown of the city.
    Everyone must be inside during a lockdown.
    The cops patrol the area.
    /unlockdown to end a lockdown]],
    weapons = {},
    command = "mayor",
    max = 1,
    salary = 1500,
    admin = 0,
    vote = true,
    hasLicense = true,
    candemote = true,
    category = "Evocity Police",
    mayor = true,
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(149)
        ply:SetHealth(149)
        ply:SetArmor(100)
    end,
    PlayerDeath = function(ply, weapon, killer)
        ply:teamBan()
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "The Mayor was killed")
    end
})

TEAM_HOBO = DarkRP.createJob("Hobo", {
    color = Color(0, 44, 255, 255),
    model = {"models/player/corpse1.mdl"},
    description = [[The lowest member of society. Everybody laughs at you.
        You have no home.
        Beg for your food and money
        Sing for everyone who passes to get money
        Make your own wooden home somewhere in a corner or outside someone else's door]],
    weapons = {"weapon_bugbait"},
    command = "hobo",
    max = 5,
    salary = 0,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Evocity Citizens",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})

TEAM_JUDGE = DarkRP.createJob("Judge", {
    color = Color(85, 250, 50, 255),
    model = "models/player/eli.mdl",
    description = [[You are the judge for your court.
    It is up to you to keep order in the court, make a verdict, and call witnesses.
    You must have high playtime to get htis job!]],
    weapons = {},
    command = "judge",
    max = 1,
    salary = 150,
    admin = 0,
    vote = true,
    category = "Court Workers",
    hasLicense = false,
    --customCheck = function(ply) return CLIENT or ply:GetUTimeTotalTime() > courtMinJudgeTime end,
    CustomCheckFailMsg = "You don't have enough playtime to be a judge."
})

TEAM_PROSECUTOR = DarkRP.createJob("Prosecutor", {
    color = Color(85, 250, 255, 255),
    model = "models/player/gman_high.mdl",
    description = [[Prosecute for the state.
    You will automatically be teleported to court.
    You must try to prove the arrestee guilty.]],
    weapons = {},
    command = "prosecutor",
    max = 1,
    salary = 200,
    admin = 0,
    vote = false,
    category = "Court Workers",
    hasLicense = false
})

TEAM_DEFENDANT = DarkRP.createJob("Defendant", {
    color = Color(255, 250, 50, 255),
    model = "models/player/gman_high.mdl",
    description = [[Use /setfee to set your cost.
    The arrestee in court may hire you to defend.]],
    weapons = {},
    command = "defendant",
    max = 3,
    salary = 50,
    admin = 0,
    vote = false,
	category = "Court Workers",
    hasLicense = false
    }}

TEAM_SSERVICE = DarkRP.createJob("Secret Service", {
	color = Color(0, 255, 255, 255),
	model = {
			"models/suits/male_01_closed_tie.mdl",
			"models/suits/male_02_closed_tie.mdl",
			"models/suits/male_03_closed_tie.mdl",
			"models/suits/male_04_closed_tie.mdl",
			"models/suits/male_05_closed_tie.mdl",
			"models/suits/male_06_closed_tie.mdl",
			"models/suits/male_07_closed_tie.mdl",
			"models/suits/male_08_closed_tie.mdl",
			"models/suits/male_09_closed_tie.mdl"
			},
	description = [[You are the mayor's personal bodyguard.
	You stay with the mayor at all times and make sure he doesn't die.]],
	weapons = {"m9k_sig_p229r", "door_ram", "weaponchecker", "arrest_stick", "unarrest_stick"},
	command = "secretservice",
	max = 3,
	salary = 90,
	admin = 0,
	vote = false,
	category = "Evocity Police",
	hasLicense = true,
})

TEAM_SECURE = DarkRP.createJob("Security", {
	color = Color(255, 250, 50, 255),
	model = "models/Police.mdl",
	description = [[You're private security.
	You can charge people to protect them or their bases!]],
	weapons = {stunstick},
	command = "securiy",
	max = 3,
	salary = 50,
	admin = 0,
	vote = false,
	category = "Evocity Citizens",
	hasLicense = true,
})

TEAM_TOW = DarkRP.createJob("Tow Truck Driver", {
	color = Color(255, 0, 0, 0),
	model = "models/monk.mdl",
	description = [[Time to tow!
	You are a tow truck driver.
	People call you and you pick 'em up.
	Don't Forget to charge!]],
	weapons = {},
	command = "towtruck",
	max = 2,
	salary = 60,
	admin = 0,
	vote = false,
	category = "Evocity Citizens",
	hasLicense = false,
})
---------------------------------------------------------

DarkRP.createDemoteGroup("Cops", {TEAM_POLICE, TEAM_CHIEF, TEAM_FBI, TEAM_SWAT})
DarkRP.createDemoteGroup("Evocity Criminals", {TEAM_GANG, TEAM_MOB, TEAM_WEED, TEAM_HACK, TEAM_AMETH, TEAM_COKE, TEAM_LSD, TEAM_METH})
DarkRP.addHitmanTeam(TEAM_MOB)