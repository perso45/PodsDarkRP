DarkRP.createShipment("AK47", {
	model = "models/weapons/w_tct_ak47.mdl",
	entity = "m9k_ak47",
	price = 120000,
	amount = 10,
	separate = true,
	pricesep = 12500,
	category = “Rifles”,
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("ACR", {
	model = "models/weapons/w_masada_acr.mdl",
	entity = "m9k_acr",
	price = 160000,
	amount = 10,
	separate = true,
	pricesep = 16500,
	category = “Rifles”,
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("FN FAL", {
	model = "models/weapons/w_fn_fal.mdl",
	entity = "m9k_fal",
	price = 200000,
	amount = 10,
	separate = true,
	pricesep = 20500,
	category = “Rifles”,
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("FAMAS", {
	model = "models/weapons/w_tct_famas.mdl",
	entity = "m9k_famas",
	price = 180000,
	amount = 10,
	separate = true,
	pricesep = 18500,
	category = “Rifles”,
	allowed = {TEAM_GUN}
})

DarkRP.createShipment("AUG 43", {
	model = "models/weapons/w_auga3.mdl",
	entity = "m9k_auga3",
	price = 175000,
	amount = 10,
	separate = true,
	pricesep = 17500,
	category = “Rifles”,
	allowed = {TEAM_GUN}
})
-----------------------------------------------
DarkRP.createShipment(“Colt 1911”, {
	model = “”,
	entity = “”,
	price = 15000,
	amount = 10,
	separate = true,
	pricesep = 1500,
	category = “Pistols”,
	allowed = {TEAM_GUN}
})

DarkRP.createShipment(“Colt Python”, {
	model = “”,
	entity = “”,
	price = 20000,
	amount = 10,
	separate = true,
	pricesep = 2500,
	category = “Pistols”,
	allowed = {TEAM_GUN}
})

DarkRP.createShipment(“Desert Eagle”, {
	model = “”,
	entity = “”,
	price = 30000,
	amount = 10,
	separate = true,
	pricesep = 3500,
	category = “Pistols”,
	allowed = {TEAM_GUN}
})

DarkRP.createShipment(“Glock 18”, {
	model = “”,
	entity = “”,
	price = 25000,
	amount = 10,
	separate = true,
	pricesep = 3000,
	category = “Pistols”,
	allowed = {TEAM_GUN}
)}

DarkRP.createShipment(“Luger”, {
	model = “”,
	entity = “”,
	price = 35000,
	amount = 10,
	separate = true,
	pricesep = 3500,
	category = “Pistols”,
	allowed = {TEAM_GUN}
)}
-----------------------------------------------
DarkRP.createShipment(“Ithaca M37”, {
	model = “”,
	entity = “”,
	price = 40000,
	amount = 10,
	separate = true,
	pricesep = 4500,
	category = “Shotguns”,
	allowed = {TEAM_GUN}
)}
-----------------------------------------------
DarkRP.createShipment(“AI AW50”, {
	model = “”,
	entity = “”,
	price = 45000,
	amount = 10,
	separate = false,
	pricesep = 999999999,
	category = “Sniper Rifles”,
	allowed = {TEAM_GUN}
)}

DarkRP.createShipment(“PSG-1”, {
	model = “”,
	entity = “”,
	price = 50000,
	amount = 10,
	separate = false,
	pricesep = 999999999,
	category = “Sniper Rifles”,
	allowed = {TEAM_GUN}
)}
-----------------------------------------------
DarkRP.createShipment(“P90”, {
	model = “”,
	entity = “”,
	price = 40000,
	amount = 10,
	separate = True,
	pricesep = 4500,
	category = “Sub Machine Guns”,
	allowed = {TEAM_GUN}
)}

DarkRP.createShipment(“MP9”, {
	model = “”,
	entity = “”,
	price = 45000,
	amount = 10,
	separate = True,
	pricesep = 5000,
	category = “Sub Machine Guns”,
	allowed = {TEAM_GUN}
)}

DarkRP.createShipment(“TEC-9”, {
	model = “”,
	entity = “”,
	price = 35000,
	amount = 10,
	separate = True,
	pricesep = 4000,
	category = “Sub Machine Guns”,
	allowed = {TEAM_GUN}
)}

DarkRP.createShipment(“KAC PDW”, {
	model = “”,
	entity = “”,
	price = 45000,
	amount = 10,
	separate = True,
	pricesep = 5000,
	category = “Sub Machine Guns”,
	allowed = {TEAM_GUN}
)}
-----------------------------------------------
DarkRP.createCategory{
	name = "Rifles",
	categories = "shipments",
	startExpanded = false,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return true end,
	sortOrder = 1,
}

DarkRP.createCategory{
	name = “Shotguns”,
	categories = “shipments”,
	startExpand = false,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return true end,
	sortOrder = 2,
}

DarkRP.createCategory{
	name = “Pistols”,
	categories = “shipments”,
	startExpand = false,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return true end,
	sortOrder = 3,
}

DarkRP.createCategory{
	name = “Sub Machine Guns”,
	categories = “shipments”,
	startExpand = false,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return true end,
	sortOrder = 4,
}

DarkRP.createCategory{
	name = “Sniper Rifles”,
	categories = “shipments”,
	startExpand = false,
	color = Color(0, 107, 0, 255),
	canSee = function(ply) return true end,
	sortOrder = 5,
}