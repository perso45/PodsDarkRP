DarkRP.createAmmoType("smg1", {
    name = "SMG Ammo",
    model = "models/Items/BoxMRounds.mdl",
    price = 50,
    amountGiven = 30
})

DarkRP.createAmmoType("ar2", {
	name = "Assualt Rifle Ammo",
	model = "models/Items/BoxMRounds.mdl",
	price = 50,
	amountGiven = 30
})
DarkRP.createAmmoType("pistol", {
	name = "Pistol Ammo",
	model = "models/Items/BoxSRounds.mdl",
	price = 35,
	amountGiven = 30
})

DarkRP.createAmmoType("357", {
	name = "357 Ammo"
	model = "models/Items/357ammo.mdl",
	price = 35,
	amountGiven = 30
})

DarkRP.createAmmoType("buckshot", {
	name = "Shotgun Ammo",
	model = "models/Items/BoxBuckshot.mdl"
	price = 50,
	amountGiven = 15
})

-------------------------------------------

DarkRP.createAmmoType("smg1", {
    name = "SMG Ammo Crate",
    model = "models/Items/ammocrate_smg1.mdl",
    price = 200,
    amountGiven = 150
})

DarkRP.createAmmoType("ar2", {
	name = "Assualt Rifle Ammo Crate",
	model = "models/Items/ammocrate_ar2.mdl",
	price = 200,
	amountGiven = 150
})